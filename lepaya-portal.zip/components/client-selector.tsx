"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Check, ChevronsUpDown, PlusCircle } from "lucide-react"

type Client = {
  id: string
  name: string
  industry: string
}

// Mock data - in a real app, this would come from an API
const clients: Client[] = [
  { id: "1", name: "Acme Corporation", industry: "Technology" },
  { id: "2", name: "Globex Corporation", industry: "Manufacturing" },
  { id: "3", name: "Initech", industry: "Technology" },
  { id: "4", name: "Massive Dynamic", industry: "Research" },
  { id: "5", name: "Stark Industries", industry: "Defense" },
  { id: "6", name: "Wayne Enterprises", industry: "Various" },
]

export function ClientSelector() {
  const [open, setOpen] = useState(false)
  const [selectedClient, setSelectedClient] = useState<Client | null>(null)
  const router = useRouter()

  const handleSelect = (client: Client) => {
    setSelectedClient(client)
    setOpen(false)
    router.push(`/dashboard/clients/${client.id}`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Select Client</CardTitle>
        <CardDescription>Choose a client to view their details and manage their programs.</CardDescription>
      </CardHeader>
      <CardContent>
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between">
              {selectedClient ? selectedClient.name : "Select a client..."}
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[300px] p-0" align="start">
            <Command>
              <CommandInput placeholder="Search clients..." />
              <CommandList>
                <CommandEmpty>No clients found.</CommandEmpty>
                <CommandGroup>
                  {clients.map((client) => (
                    <CommandItem
                      key={client.id}
                      onSelect={() => handleSelect(client)}
                      className="flex items-center justify-between"
                    >
                      <div>
                        <span>{client.name}</span>
                        <span className="ml-2 text-xs text-muted-foreground">{client.industry}</span>
                      </div>
                      {selectedClient?.id === client.id && <Check className="h-4 w-4" />}
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full" onClick={() => router.push("/dashboard/clients/new")}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add New Client
        </Button>
      </CardFooter>
    </Card>
  )
}
