"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { WorkplaceNeedForm } from "@/components/workplace-need-form"

interface WorkplaceNeedsProps {
  clientId: string
}

interface WorkplaceNeed {
  id: string
  targetAudience: string
  characteristics: string
  goals: string
  challenges: string
  successMetrics: string
  desiredBehaviors: string
}

export function WorkplaceNeeds({ clientId }: WorkplaceNeedsProps) {
  const { toast } = useToast()
  const [needs, setNeeds] = useState<WorkplaceNeed[]>([
    {
      id: "1",
      targetAudience: "Leaders",
      characteristics:
        "Senior managers with 5+ years of experience, responsible for team management and strategic decisions.",
      goals: "Improve team performance, develop leadership skills, and drive innovation within their departments.",
      challenges:
        "Managing remote teams, adapting to rapid market changes, and balancing operational and strategic responsibilities.",
      successMetrics:
        "Team productivity, employee satisfaction scores, and successful implementation of strategic initiatives.",
      desiredBehaviors:
        "Effective delegation, providing constructive feedback, and fostering a culture of innovation and continuous improvement.",
    },
    {
      id: "2",
      targetAudience: "Professionals",
      characteristics: "Mid-level employees with specialized skills in their respective domains.",
      goals:
        "Enhance technical expertise, improve cross-functional collaboration, and develop career advancement skills.",
      challenges: "Keeping up with industry trends, managing workload, and navigating organizational complexity.",
      successMetrics: "Project completion rates, quality of deliverables, and contribution to team objectives.",
      desiredBehaviors:
        "Proactive problem-solving, effective communication across teams, and continuous learning and skill development.",
    },
  ])
  const [adding, setAdding] = useState(false)
  const [editing, setEditing] = useState<string | null>(null)

  const handleAdd = (need: Omit<WorkplaceNeed, "id">) => {
    const newNeed = {
      ...need,
      id: Math.random().toString(36).substring(7),
    }

    setNeeds((prev) => [...prev, newNeed])
    setAdding(false)

    toast({
      title: "Workplace need added",
      description: "The workplace need has been added successfully.",
    })
  }

  const handleUpdate = (id: string, need: Omit<WorkplaceNeed, "id">) => {
    setNeeds((prev) => prev.map((item) => (item.id === id ? { ...item, ...need } : item)))

    setEditing(null)

    toast({
      title: "Workplace need updated",
      description: "The workplace need has been updated successfully.",
    })
  }

  const handleDelete = (id: string) => {
    setNeeds((prev) => prev.filter((need) => need.id !== id))

    toast({
      title: "Workplace need deleted",
      description: "The workplace need has been removed.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Workplace Needs</h2>
        <Button onClick={() => setAdding(true)} disabled={adding}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Workplace Need
        </Button>
      </div>

      {adding && (
        <Card>
          <CardHeader>
            <CardTitle>Add Workplace Need</CardTitle>
            <CardDescription>Define a new workplace need for a specific target audience.</CardDescription>
          </CardHeader>
          <CardContent>
            <WorkplaceNeedForm onSubmit={handleAdd} onCancel={() => setAdding(false)} />
          </CardContent>
        </Card>
      )}

      {needs.length > 0 ? (
        <Tabs defaultValue={needs[0].id} className="w-full">
          <TabsList className="grid w-full" style={{ gridTemplateColumns: `repeat(${needs.length}, 1fr)` }}>
            {needs.map((need) => (
              <TabsTrigger key={need.id} value={need.id}>
                {need.targetAudience}
              </TabsTrigger>
            ))}
          </TabsList>

          {needs.map((need) => (
            <TabsContent key={need.id} value={need.id} className="space-y-4 pt-4">
              {editing === need.id ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Edit Workplace Need</CardTitle>
                    <CardDescription>Update the workplace need for {need.targetAudience}.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <WorkplaceNeedForm
                      initialData={need}
                      onSubmit={(data) => handleUpdate(need.id, data)}
                      onCancel={() => setEditing(null)}
                    />
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader className="flex flex-row items-start justify-between space-y-0">
                    <div>
                      <CardTitle>{need.targetAudience}</CardTitle>
                      <CardDescription>Workplace needs for {need.targetAudience.toLowerCase()}</CardDescription>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={() => setEditing(need.id)}>
                        Edit
                      </Button>
                      <Button variant="destructive" size="sm" onClick={() => handleDelete(need.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-medium">Characteristics</h3>
                      <p className="text-sm text-muted-foreground">{need.characteristics}</p>
                    </div>
                    <div>
                      <h3 className="font-medium">Goals</h3>
                      <p className="text-sm text-muted-foreground">{need.goals}</p>
                    </div>
                    <div>
                      <h3 className="font-medium">Challenges</h3>
                      <p className="text-sm text-muted-foreground">{need.challenges}</p>
                    </div>
                    <div>
                      <h3 className="font-medium">Success Metrics</h3>
                      <p className="text-sm text-muted-foreground">{need.successMetrics}</p>
                    </div>
                    <div>
                      <h3 className="font-medium">Desired Behaviors</h3>
                      <p className="text-sm text-muted-foreground">{need.desiredBehaviors}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          ))}
        </Tabs>
      ) : (
        <Card>
          <CardContent className="flex h-40 flex-col items-center justify-center space-y-4 p-6">
            <p className="text-center text-muted-foreground">
              No workplace needs defined yet. Add your first workplace need to get started.
            </p>
            <Button onClick={() => setAdding(true)}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Workplace Need
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
