"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Globe, Plus, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface LinkManagerProps {
  clientId: string
}

interface Link {
  id: string
  title: string
  url: string
}

export function LinkManager({ clientId }: LinkManagerProps) {
  const { toast } = useToast()
  const [links, setLinks] = useState<Link[]>([
    {
      id: "1",
      title: "Company Website",
      url: "https://example.com",
    },
    {
      id: "2",
      title: "Annual Report",
      url: "https://example.com/annual-report",
    },
  ])
  const [newLink, setNewLink] = useState({ title: "", url: "" })
  const [adding, setAdding] = useState(false)

  const handleAdd = () => {
    if (!newLink.title || !newLink.url) {
      toast({
        title: "Missing information",
        description: "Please provide both a title and URL.",
        variant: "destructive",
      })
      return
    }

    const link = {
      id: Math.random().toString(36).substring(7),
      title: newLink.title,
      url: newLink.url,
    }

    setLinks((prev) => [...prev, link])
    setNewLink({ title: "", url: "" })
    setAdding(false)

    toast({
      title: "Link added",
      description: "The link has been added successfully.",
    })
  }

  const handleDelete = (id: string) => {
    setLinks((prev) => prev.filter((link) => link.id !== id))
    toast({
      title: "Link deleted",
      description: "The link has been removed.",
    })
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={() => setAdding(!adding)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Link
        </Button>
      </div>

      {adding && (
        <Card className="p-4">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Input
                placeholder="Link Title"
                value={newLink.title}
                onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Input
                placeholder="URL (https://...)"
                value={newLink.url}
                onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setAdding(false)}>
                Cancel
              </Button>
              <Button onClick={handleAdd}>Add Link</Button>
            </div>
          </div>
        </Card>
      )}

      <div className="space-y-2">
        {links.map((link) => (
          <Card key={link.id} className="flex items-center justify-between p-3">
            <div className="flex items-center space-x-3">
              <Globe className="h-5 w-5 text-lepaya-blue" />
              <div>
                <p className="font-medium">{link.title}</p>
                <a
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-blue-500 hover:underline"
                >
                  {link.url}
                </a>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => handleDelete(link.id)}>
              <Trash2 className="h-4 w-4" />
              <span className="sr-only">Delete</span>
            </Button>
          </Card>
        ))}

        {links.length === 0 && (
          <div className="flex h-24 items-center justify-center rounded-md border border-dashed">
            <p className="text-sm text-muted-foreground">No links added yet</p>
          </div>
        )}
      </div>
    </div>
  )
}
