"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface WorkplaceNeedFormProps {
  initialData?: {
    targetAudience: string
    characteristics: string
    goals: string
    challenges: string
    successMetrics: string
    desiredBehaviors: string
  }
  onSubmit: (data: {
    targetAudience: string
    characteristics: string
    goals: string
    challenges: string
    successMetrics: string
    desiredBehaviors: string
  }) => void
  onCancel: () => void
}

export function WorkplaceNeedForm({ initialData, onSubmit, onCancel }: WorkplaceNeedFormProps) {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    targetAudience: initialData?.targetAudience || "",
    characteristics: initialData?.characteristics || "",
    goals: initialData?.goals || "",
    challenges: initialData?.challenges || "",
    successMetrics: initialData?.successMetrics || "",
    desiredBehaviors: initialData?.desiredBehaviors || "",
  })
  const [generating, setGenerating] = useState<string | null>(null)

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.targetAudience) {
      toast({
        title: "Missing information",
        description: "Please select a target audience.",
        variant: "destructive",
      })
      return
    }

    onSubmit(formData)
  }

  const generateContent = (field: string) => {
    setGenerating(field)

    // Simulate AI generation
    setTimeout(() => {
      const generatedContent: Record<string, Record<string, string>> = {
        "Young Talent": {
          characteristics:
            "Recent graduates or early-career professionals with 0-3 years of experience. Tech-savvy, eager to learn, and seeking growth opportunities.",
          goals:
            "Develop foundational skills, understand organizational processes, and establish professional identity.",
          challenges:
            "Limited practical experience, navigating corporate culture, and finding mentorship opportunities.",
          successMetrics:
            "Skill acquisition rate, contribution to team projects, and progress against personal development plans.",
          desiredBehaviors:
            "Proactive learning, seeking feedback, collaborating effectively with team members, and demonstrating initiative.",
        },
        Professionals: {
          characteristics:
            "Mid-level employees with 3-7 years of experience. Subject matter experts with specialized skills and growing leadership responsibilities.",
          goals: "Deepen expertise, expand cross-functional knowledge, and prepare for leadership roles.",
          challenges:
            "Balancing technical and managerial responsibilities, staying current with industry trends, and managing increasing workloads.",
          successMetrics:
            "Project outcomes, innovation contributions, mentoring effectiveness, and team collaboration ratings.",
          desiredBehaviors:
            "Knowledge sharing, mentoring junior colleagues, driving innovation, and effective cross-functional collaboration.",
        },
        Leaders: {
          characteristics:
            "Experienced managers with 7+ years of experience. Responsible for team performance, strategic planning, and organizational alignment.",
          goals: "Develop strategic thinking, enhance team leadership, and drive organizational change.",
          challenges:
            "Managing diverse teams, navigating organizational politics, and balancing operational and strategic priorities.",
          successMetrics:
            "Team performance indicators, employee engagement scores, successful change initiatives, and business impact metrics.",
          desiredBehaviors:
            "Strategic decision-making, effective delegation, coaching team members, and championing organizational values.",
        },
        Commercial: {
          characteristics:
            "Sales and business development professionals focused on revenue generation and client relationships.",
          goals: "Exceed revenue targets, expand client base, and develop long-term client relationships.",
          challenges:
            "Meeting increasing sales targets, adapting to changing market conditions, and differentiating from competitors.",
          successMetrics:
            "Revenue achievement, new client acquisition, client retention rates, and sales cycle efficiency.",
          desiredBehaviors:
            "Consultative selling, relationship building, effective negotiation, and collaborative problem-solving with clients.",
        },
      }

      if (formData.targetAudience && field !== "targetAudience") {
        const content = generatedContent[formData.targetAudience]?.[field]
        if (content) {
          setFormData((prev) => ({ ...prev, [field]: content }))
        }
      }

      setGenerating(null)

      toast({
        title: "Content generated",
        description: "AI has generated content for this field.",
      })
    }, 1500)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="target-audience">Target Audience</Label>
        <Select value={formData.targetAudience} onValueChange={(value) => handleChange("targetAudience", value)}>
          <SelectTrigger id="target-audience">
            <SelectValue placeholder="Select target audience" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Young Talent">Young Talent</SelectItem>
            <SelectItem value="Professionals">Professionals</SelectItem>
            <SelectItem value="Leaders">Leaders</SelectItem>
            <SelectItem value="Commercial">Commercial</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="characteristics">Characteristics</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => generateContent("characteristics")}
            disabled={!formData.targetAudience || generating === "characteristics"}
          >
            {generating === "characteristics" ? (
              <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
            ) : (
              <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
            )}
            Generate with AI
          </Button>
        </div>
        <Textarea
          id="characteristics"
          placeholder="Describe the characteristics of this target audience"
          value={formData.characteristics}
          onChange={(e) => handleChange("characteristics", e.target.value)}
          className="min-h-[80px]"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="goals">Goals</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => generateContent("goals")}
            disabled={!formData.targetAudience || generating === "goals"}
          >
            {generating === "goals" ? (
              <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
            ) : (
              <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
            )}
            Generate with AI
          </Button>
        </div>
        <Textarea
          id="goals"
          placeholder="What are the goals of this target audience?"
          value={formData.goals}
          onChange={(e) => handleChange("goals", e.target.value)}
          className="min-h-[80px]"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="challenges">Challenges</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => generateContent("challenges")}
            disabled={!formData.targetAudience || generating === "challenges"}
          >
            {generating === "challenges" ? (
              <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
            ) : (
              <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
            )}
            Generate with AI
          </Button>
        </div>
        <Textarea
          id="challenges"
          placeholder="What challenges does this target audience face?"
          value={formData.challenges}
          onChange={(e) => handleChange("challenges", e.target.value)}
          className="min-h-[80px]"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="success-metrics">Success Metrics</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => generateContent("successMetrics")}
            disabled={!formData.targetAudience || generating === "successMetrics"}
          >
            {generating === "successMetrics" ? (
              <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
            ) : (
              <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
            )}
            Generate with AI
          </Button>
        </div>
        <Textarea
          id="success-metrics"
          placeholder="How is success measured for this target audience?"
          value={formData.successMetrics}
          onChange={(e) => handleChange("successMetrics", e.target.value)}
          className="min-h-[80px]"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="desired-behaviors">Desired Behaviors</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => generateContent("desiredBehaviors")}
            disabled={!formData.targetAudience || generating === "desiredBehaviors"}
          >
            {generating === "desiredBehaviors" ? (
              <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
            ) : (
              <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
            )}
            Generate with AI
          </Button>
        </div>
        <Textarea
          id="desired-behaviors"
          placeholder="What behaviors do you want to see from this target audience?"
          value={formData.desiredBehaviors}
          onChange={(e) => handleChange("desiredBehaviors", e.target.value)}
          className="min-h-[80px]"
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">{initialData ? "Update" : "Add"} Workplace Need</Button>
      </div>
    </form>
  )
}
