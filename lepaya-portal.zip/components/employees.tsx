"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { PlusCircle, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface EmployeesProps {
  clientId: string
}

interface Employee {
  id: string
  name: string
  email: string
  role: string
  department: string
  accessLevel: "admin" | "editor" | "viewer"
  avatar?: string
}

export function Employees({ clientId }: EmployeesProps) {
  const { toast } = useToast()
  const [employees, setEmployees] = useState<Employee[]>([
    {
      id: "1",
      name: "Sarah Johnson",
      email: "sarah.johnson@example.com",
      role: "HR Director",
      department: "Human Resources",
      accessLevel: "admin",
    },
    {
      id: "2",
      name: "Michael Chen",
      email: "michael.chen@example.com",
      role: "Learning & Development Manager",
      department: "Human Resources",
      accessLevel: "editor",
    },
    {
      id: "3",
      name: "Emma Rodriguez",
      email: "emma.rodriguez@example.com",
      role: "Talent Development Specialist",
      department: "Human Resources",
      accessLevel: "viewer",
    },
    {
      id: "4",
      name: "David Kim",
      email: "david.kim@example.com",
      role: "Chief People Officer",
      department: "Executive",
      accessLevel: "admin",
    },
    {
      id: "5",
      name: "Lisa Patel",
      email: "lisa.patel@example.com",
      role: "Training Coordinator",
      department: "Human Resources",
      accessLevel: "viewer",
    },
  ])
  const [searchQuery, setSearchQuery] = useState("")

  const filteredEmployees = employees.filter((employee) => {
    const query = searchQuery.toLowerCase()
    return (
      employee.name.toLowerCase().includes(query) ||
      employee.email.toLowerCase().includes(query) ||
      employee.role.toLowerCase().includes(query) ||
      employee.department.toLowerCase().includes(query)
    )
  })

  const getAccessLevelBadge = (level: string) => {
    switch (level) {
      case "admin":
        return <Badge className="bg-lepaya-purple">Admin</Badge>
      case "editor":
        return <Badge className="bg-lepaya-teal">Editor</Badge>
      case "viewer":
        return <Badge className="bg-lepaya-blue">Viewer</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  const handleAddEmployee = () => {
    toast({
      title: "Feature coming soon",
      description: "The ability to add new employees will be available in a future update.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Portal Access</h2>
        <Button onClick={handleAddEmployee}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Employee
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Employees with Portal Access</CardTitle>
          <CardDescription>Manage employees who have access to the Lepaya client portal.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search employees..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              {filteredEmployees.length > 0 ? (
                filteredEmployees.map((employee) => (
                  <div key={employee.id} className="flex items-center justify-between rounded-md border p-3">
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarImage src={employee.avatar || "/placeholder.svg"} alt={employee.name} />
                        <AvatarFallback>
                          {employee.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-muted-foreground">{employee.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="hidden text-right md:block">
                        <p className="text-sm font-medium">{employee.role}</p>
                        <p className="text-sm text-muted-foreground">{employee.department}</p>
                      </div>
                      {getAccessLevelBadge(employee.accessLevel)}
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex h-24 items-center justify-center rounded-md border border-dashed">
                  <p className="text-sm text-muted-foreground">No employees found</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
