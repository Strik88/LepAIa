"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

interface ConfigurationProps {
  clientId: string
}

export function Configuration({ clientId }: ConfigurationProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  const [generalConfig, setGeneralConfig] = useState({
    portalName: "Acme Learning Portal",
    primaryColor: "#1E3C70",
    logoUrl: "",
    language: "english",
    timezone: "Europe/Amsterdam",
  })

  const [notificationConfig, setNotificationConfig] = useState({
    emailNotifications: true,
    programUpdates: true,
    weeklyReports: true,
    participantProgress: true,
  })

  const [integrationConfig, setIntegrationConfig] = useState({
    enableHRIS: false,
    hrisApiKey: "",
    enableLMS: true,
    lmsApiKey: "lms_api_key_123456",
  })

  const handleGeneralChange = (field: string, value: string | boolean) => {
    setGeneralConfig((prev) => ({ ...prev, [field]: value }))
  }

  const handleNotificationChange = (field: string, value: boolean) => {
    setNotificationConfig((prev) => ({ ...prev, [field]: value }))
  }

  const handleIntegrationChange = (field: string, value: string | boolean) => {
    setIntegrationConfig((prev) => ({ ...prev, [field]: value }))
  }

  const handleSave = () => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Configuration saved",
        description: "Your configuration changes have been saved successfully.",
      })
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Configure the general settings for this client's portal.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="portal-name">Portal Name</Label>
                <Input
                  id="portal-name"
                  value={generalConfig.portalName}
                  onChange={(e) => handleGeneralChange("portalName", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="primary-color">Primary Color</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    id="primary-color"
                    type="text"
                    value={generalConfig.primaryColor}
                    onChange={(e) => handleGeneralChange("primaryColor", e.target.value)}
                  />
                  <div
                    className="h-10 w-10 rounded-md border"
                    style={{ backgroundColor: generalConfig.primaryColor }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo-url">Logo URL</Label>
                <Input
                  id="logo-url"
                  placeholder="https://example.com/logo.png"
                  value={generalConfig.logoUrl}
                  onChange={(e) => handleGeneralChange("logoUrl", e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select
                    value={generalConfig.language}
                    onValueChange={(value) => handleGeneralChange("language", value)}
                  >
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="dutch">Dutch</SelectItem>
                      <SelectItem value="german">German</SelectItem>
                      <SelectItem value="french">French</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select
                    value={generalConfig.timezone}
                    onValueChange={(value) => handleGeneralChange("timezone", value)}
                  >
                    <SelectTrigger id="timezone">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Europe/Amsterdam">Europe/Amsterdam</SelectItem>
                      <SelectItem value="Europe/London">Europe/London</SelectItem>
                      <SelectItem value="America/New_York">America/New_York</SelectItem>
                      <SelectItem value="Asia/Singapore">Asia/Singapore</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure notification preferences for this client.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between space-y-0 pb-2">
                <Label htmlFor="email-notifications">Email Notifications</Label>
                <Switch
                  id="email-notifications"
                  checked={notificationConfig.emailNotifications}
                  onCheckedChange={(checked) => handleNotificationChange("emailNotifications", checked)}
                />
              </div>

              <div className="flex items-center justify-between space-y-0 pb-2">
                <Label htmlFor="program-updates">Program Updates</Label>
                <Switch
                  id="program-updates"
                  checked={notificationConfig.programUpdates}
                  onCheckedChange={(checked) => handleNotificationChange("programUpdates", checked)}
                />
              </div>

              <div className="flex items-center justify-between space-y-0 pb-2">
                <Label htmlFor="weekly-reports">Weekly Reports</Label>
                <Switch
                  id="weekly-reports"
                  checked={notificationConfig.weeklyReports}
                  onCheckedChange={(checked) => handleNotificationChange("weeklyReports", checked)}
                />
              </div>

              <div className="flex items-center justify-between space-y-0 pb-2">
                <Label htmlFor="participant-progress">Participant Progress</Label>
                <Switch
                  id="participant-progress"
                  checked={notificationConfig.participantProgress}
                  onCheckedChange={(checked) => handleNotificationChange("participantProgress", checked)}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Integration Settings</CardTitle>
              <CardDescription>Configure third-party integrations for this client.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between space-y-0">
                  <div>
                    <h4 className="font-medium">HRIS Integration</h4>
                    <p className="text-sm text-muted-foreground">Connect to the client's HR Information System</p>
                  </div>
                  <Switch
                    id="enable-hris"
                    checked={integrationConfig.enableHRIS}
                    onCheckedChange={(checked) => handleIntegrationChange("enableHRIS", checked)}
                  />
                </div>

                {integrationConfig.enableHRIS && (
                  <div className="space-y-2">
                    <Label htmlFor="hris-api-key">HRIS API Key</Label>
                    <Input
                      id="hris-api-key"
                      type="password"
                      value={integrationConfig.hrisApiKey}
                      onChange={(e) => handleIntegrationChange("hrisApiKey", e.target.value)}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between space-y-0">
                  <div>
                    <h4 className="font-medium">LMS Integration</h4>
                    <p className="text-sm text-muted-foreground">Connect to the client's Learning Management System</p>
                  </div>
                  <Switch
                    id="enable-lms"
                    checked={integrationConfig.enableLMS}
                    onCheckedChange={(checked) => handleIntegrationChange("enableLMS", checked)}
                  />
                </div>

                {integrationConfig.enableLMS && (
                  <div className="space-y-2">
                    <Label htmlFor="lms-api-key">LMS API Key</Label>
                    <Input
                      id="lms-api-key"
                      type="password"
                      value={integrationConfig.lmsApiKey}
                      onChange={(e) => handleIntegrationChange("lmsApiKey", e.target.value)}
                    />
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
