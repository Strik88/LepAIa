"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { PlusCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ProgramsProps {
  clientId: string
}

interface Program {
  id: string
  name: string
  description: string
  targetAudience: string
  waves: number
  status: "active" | "completed" | "planned"
  startDate: string
  endDate: string
}

export function Programs({ clientId }: ProgramsProps) {
  const { toast } = useToast()
  const [programs, setPrograms] = useState<Program[]>([
    {
      id: "1",
      name: "Leadership Excellence",
      description: "A comprehensive program designed to enhance leadership capabilities across the organization.",
      targetAudience: "Leaders",
      waves: 3,
      status: "active",
      startDate: "2023-09-01",
      endDate: "2024-06-30",
    },
    {
      id: "2",
      name: "Digital Transformation Skills",
      description: "Equipping professionals with the skills needed to drive digital transformation initiatives.",
      targetAudience: "Professionals",
      waves: 2,
      status: "planned",
      startDate: "2024-01-15",
      endDate: "2024-12-15",
    },
    {
      id: "3",
      name: "Sales Excellence",
      description: "Enhancing consultative selling skills and customer relationship management.",
      targetAudience: "Commercial",
      waves: 4,
      status: "completed",
      startDate: "2022-06-01",
      endDate: "2023-05-30",
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "completed":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "planned":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const handleAddProgram = () => {
    toast({
      title: "Feature coming soon",
      description: "The ability to add new programs will be available in a future update.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Learning Programs</h2>
        <Button onClick={handleAddProgram}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Program
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {programs.map((program) => (
          <Card key={program.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle>{program.name}</CardTitle>
                  <CardDescription className="mt-1">Target: {program.targetAudience}</CardDescription>
                </div>
                <Badge className={getStatusColor(program.status)}>
                  {program.status.charAt(0).toUpperCase() + program.status.slice(1)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">{program.description}</p>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">Waves</p>
                    <p className="text-muted-foreground">{program.waves}</p>
                  </div>
                  <div>
                    <p className="font-medium">Timeline</p>
                    <p className="text-muted-foreground">
                      {formatDate(program.startDate)} - {formatDate(program.endDate)}
                    </p>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {programs.length === 0 && (
        <Card>
          <CardContent className="flex h-40 flex-col items-center justify-center space-y-4 p-6">
            <p className="text-center text-muted-foreground">
              No programs defined yet. Add your first program to get started.
            </p>
            <Button onClick={handleAddProgram}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Program
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
