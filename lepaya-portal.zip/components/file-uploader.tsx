"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { FileText, Upload, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface FileUploaderProps {
  clientId: string
}

interface UploadedFile {
  id: string
  name: string
  size: number
  type: string
  uploadedAt: Date
}

export function FileUploader({ clientId }: FileUploaderProps) {
  const { toast } = useToast()
  const [files, setFiles] = useState<UploadedFile[]>([
    {
      id: "1",
      name: "RFP_Document.pdf",
      size: 2500000,
      type: "application/pdf",
      uploadedAt: new Date(),
    },
    {
      id: "2",
      name: "Company_Overview.pptx",
      size: 4200000,
      type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      uploadedAt: new Date(),
    },
  ])
  const [uploading, setUploading] = useState(false)

  const handleUpload = () => {
    setUploading(true)
    // Simulate file upload
    setTimeout(() => {
      const newFile = {
        id: Math.random().toString(36).substring(7),
        name: "New_Document.pdf",
        size: 3100000,
        type: "application/pdf",
        uploadedAt: new Date(),
      }
      setFiles((prev) => [...prev, newFile])
      setUploading(false)
      toast({
        title: "File uploaded",
        description: "Your file has been uploaded successfully.",
      })
    }, 1500)
  }

  const handleDelete = (id: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== id))
    toast({
      title: "File deleted",
      description: "The file has been removed.",
    })
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " bytes"
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / 1048576).toFixed(1) + " MB"
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={handleUpload} disabled={uploading}>
          {uploading ? (
            <>
              <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
              Uploading...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Upload File
            </>
          )}
        </Button>
      </div>

      <div className="space-y-2">
        {files.map((file) => (
          <Card key={file.id} className="flex items-center justify-between p-3">
            <div className="flex items-center space-x-3">
              <FileText className="h-8 w-8 text-lepaya-blue" />
              <div>
                <p className="font-medium">{file.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatFileSize(file.size)} • {file.uploadedAt.toLocaleDateString()}
                </p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => handleDelete(file.id)}>
              <X className="h-4 w-4" />
              <span className="sr-only">Delete</span>
            </Button>
          </Card>
        ))}

        {files.length === 0 && (
          <div className="flex h-24 items-center justify-center rounded-md border border-dashed">
            <p className="text-sm text-muted-foreground">No files uploaded yet</p>
          </div>
        )}
      </div>
    </div>
  )
}
