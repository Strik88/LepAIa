"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileUploader } from "@/components/file-uploader"
import { LinkManager } from "@/components/link-manager"
import { Sparkles } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface CompanyProfileProps {
  clientId: string
}

export function CompanyProfile({ clientId }: CompanyProfileProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState<string | null>(null)

  // Mock data - in a real app, this would come from an API
  const [companyData, setCompanyData] = useState({
    description: "",
    revenueModel: "",
    industry: "",
    challenges: "",
    priorities: "",
    additionalInfo: "",
  })

  const handleChange = (field: string, value: string) => {
    setCompanyData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSave = () => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Profile saved",
        description: "The company profile has been saved successfully.",
      })
    }, 1000)
  }

  const generateContent = (field: string) => {
    setGenerating(field)
    // Simulate AI generation
    setTimeout(() => {
      const generatedContent = {
        description:
          "Acme Corporation is a leading technology company specializing in innovative software solutions for enterprise clients. With a focus on AI and machine learning, they develop cutting-edge products that help businesses streamline operations and improve decision-making processes.",
        revenueModel:
          "Acme generates revenue primarily through subscription-based SaaS products, enterprise licensing agreements, and professional services. Their recurring revenue model provides stability while allowing for scalable growth.",
        industry:
          "Technology sector, specifically in the enterprise software and AI solutions space. They operate globally with a strong presence in North America, Europe, and Asia-Pacific regions.",
        challenges:
          "Facing increased competition from emerging startups, rapid technological changes requiring constant innovation, and the need to maintain high security standards while scaling their cloud infrastructure.",
        priorities:
          "Expanding their AI capabilities, entering new international markets, improving customer retention rates, and developing more integrated product offerings to increase customer lifetime value.",
        additionalInfo:
          "Recently completed a Series C funding round of $75M to accelerate product development and international expansion. Planning to increase their workforce by 30% over the next 18 months.",
      }

      setCompanyData((prev) => ({
        ...prev,
        [field]: generatedContent[field as keyof typeof generatedContent],
      }))

      setGenerating(null)

      toast({
        title: "Content generated",
        description: "AI has generated content for this field.",
      })
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Company Overview</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="strategic">Strategic Information</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Organization Overview</CardTitle>
              <CardDescription>Basic information about the organization and its business model.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="description">What does the organization do?</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => generateContent("description")}
                    disabled={generating === "description"}
                  >
                    {generating === "description" ? (
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="description"
                  placeholder="Describe the organization's main activities and focus"
                  className="min-h-[100px]"
                  value={companyData.description}
                  onChange={(e) => handleChange("description", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="revenue-model">How does it generate revenue?</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => generateContent("revenueModel")}
                    disabled={generating === "revenueModel"}
                  >
                    {generating === "revenueModel" ? (
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="revenue-model"
                  placeholder="Describe the revenue model and business approach"
                  className="min-h-[100px]"
                  value={companyData.revenueModel}
                  onChange={(e) => handleChange("revenueModel", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="industry">Industry Information</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => generateContent("industry")}
                    disabled={generating === "industry"}
                  >
                    {generating === "industry" ? (
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="industry"
                  placeholder="Describe the industry context and market position"
                  className="min-h-[100px]"
                  value={companyData.industry}
                  onChange={(e) => handleChange("industry", e.target.value)}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Resources & Documents</CardTitle>
              <CardDescription>Upload documents and add links related to this client.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Documents</Label>
                <FileUploader clientId={clientId} />
              </div>

              <div className="space-y-2">
                <Label>Important Links</Label>
                <LinkManager clientId={clientId} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strategic" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Strategic Information</CardTitle>
              <CardDescription>Information about challenges, priorities, and additional context.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="challenges">Challenges</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => generateContent("challenges")}
                    disabled={generating === "challenges"}
                  >
                    {generating === "challenges" ? (
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="challenges"
                  placeholder="Describe the key challenges the organization is facing"
                  className="min-h-[100px]"
                  value={companyData.challenges}
                  onChange={(e) => handleChange("challenges", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="priorities">Strategic Priorities</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => generateContent("priorities")}
                    disabled={generating === "priorities"}
                  >
                    {generating === "priorities" ? (
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="priorities"
                  placeholder="List the strategic priorities for the next 1-3 years"
                  className="min-h-[100px]"
                  value={companyData.priorities}
                  onChange={(e) => handleChange("priorities", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="additional-info">Additional Information</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => generateContent("additionalInfo")}
                    disabled={generating === "additionalInfo"}
                  >
                    {generating === "additionalInfo" ? (
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 text-lepaya-yellow" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="additional-info"
                  placeholder="Any other relevant information about the organization"
                  className="min-h-[100px]"
                  value={companyData.additionalInfo}
                  onChange={(e) => handleChange("additionalInfo", e.target.value)}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></span>
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
