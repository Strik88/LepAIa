"use client"

import { ClientHeader } from "@/components/client-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CompanyProfile } from "@/components/company-profile"
import { WorkplaceNeeds } from "@/components/workplace-needs"
import { Programs } from "@/components/programs"
import { Employees } from "@/components/employees"
import { Configuration } from "@/components/configuration"
import { useParams } from "next/navigation"
import { useState, useEffect } from "react"

export default function ClientPage() {
  const params = useParams()
  const clientId = params.clientId as string
  const [client, setClient] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate API call to fetch client data
    const fetchClient = async () => {
      setLoading(true)
      // In a real app, this would be an API call
      setTimeout(() => {
        setClient({
          id: clientId,
          name: "Acme Corporation",
          industry: "Technology",
          logo: "/placeholder.svg?height=80&width=80",
        })
        setLoading(false)
      }, 500)
    }

    fetchClient()
  }, [clientId])

  if (loading) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-lepaya-blue"></div>
        </div>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <ClientHeader client={client} />
      <Tabs defaultValue="company" className="mt-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="company">Company Profile</TabsTrigger>
          <TabsTrigger value="workplace">Workplace Needs</TabsTrigger>
          <TabsTrigger value="programs">Programs</TabsTrigger>
          <TabsTrigger value="employees">Employees</TabsTrigger>
          <TabsTrigger value="configuration">Configuration</TabsTrigger>
        </TabsList>
        <TabsContent value="company" className="mt-6">
          <CompanyProfile clientId={clientId} />
        </TabsContent>
        <TabsContent value="workplace" className="mt-6">
          <WorkplaceNeeds clientId={clientId} />
        </TabsContent>
        <TabsContent value="programs" className="mt-6">
          <Programs clientId={clientId} />
        </TabsContent>
        <TabsContent value="employees" className="mt-6">
          <Employees clientId={clientId} />
        </TabsContent>
        <TabsContent value="configuration" className="mt-6">
          <Configuration clientId={clientId} />
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}
